
const express = require("express");
const app = express();

//http://location:3000/:: URL::API::REST API
//async req
app.get("/", (req, res) => {
    const id = req.query;
    const username = req.query.username;
    const contact = req.query.contact;
    const email = req.query.email;


    const json = { id: 1, title: "shubam Lothe" };
    res.json(json);
});


app.get("/search", (req, res) => {
    const json = { id: 100, title: "i am search" };
    res.json(json);
});



app.listen(3000);