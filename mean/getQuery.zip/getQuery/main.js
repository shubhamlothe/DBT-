const ex = require('express');
const cors = require('cors');
const app = ex();
app.use(cors());
app.use(ex.json());
const dbadduser = require('./addData');
app.get("/adduser", async (req, res) => {
    try {
        const input = req.query;
        await dbadduser.addUser(input);
        res.json({ message: "success" });
    } catch (err) {
        res.json({ message: "fail", err });
    }
}
);
app.listen(3000);
