const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const DB_CONFIG = {
    host: "localhost",
    user: "root",
    password: "asdf",
    database: "conSample",
};

let addUser = async (input) => {
    const connection = mysql.createConnection(DB_CONFIG);
    await connection.connectAsync();

    let sql =
        "INSERT INTO USER VALUES (?, ?, ?, ?)";
    console.log(input);
    await connection.queryAsync(sql, [
        input.id,
        input.name,
        input.email,
        input.contact,
    ]);
    console.log('rows affected')
    await connection.endAsync();
};

module.exports = { addUser };